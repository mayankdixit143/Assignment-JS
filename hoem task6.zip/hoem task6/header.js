let header=`<div class="header-content">
		<div class="icon">
			<img src="youtubeIcon.png" alt="Youtube Image">
		</div>
		<div class="serach">
		<input type="text" name="search" class="search-box" placeholder="Serach">
		<button class="search-button"><i class="fa fa-search"></i></button>
		</div>
	</div>`;

document.getElementById('main-Header').innerHTML=header;
