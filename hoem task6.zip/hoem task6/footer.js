let footer=`
<div id=footer>
	<p>
		© YouTubeSearch 2021
	</p>
</div>`;

document.getElementById('main-Footer').innerHTML=footer