let searchButton=document.querySelector('.search-button')
let searchInput=document.querySelector('.search-box')
let nextpage;
let currpage;
let thumbnailContainer;
let pagenumber;
let items;
let count=1;
let list=[];
let totalData;


const key='AIzaSyDjx9aqUnxt7IutrG4pep03MlV7pxIUbJo';

searchButton.addEve